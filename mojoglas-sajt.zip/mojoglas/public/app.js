const CATEGORIES = [
 {name:'Automobili',icon:'🚗'},{name:'Nekretnine',icon:'🏡'},{name:'Telefoni',icon:'📱'},{name:'Računari',icon:'💻'},
 {name:'Kuća i bašta',icon:'🪴'},{name:'Alati',icon:'🛠️'},{name:'Odeća i obuća',icon:'👟'},{name:'Ostalo',icon:'✨'}
];
let me = null, ads = [], activeCategory = '', authMode = 'login';
const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money = n => new Intl.NumberFormat('sr-RS',{maximumFractionDigits:0}).format(Number(n)||0) + ' RSD';
const iconFor = cat => (CATEGORIES.find(c=>c.name===cat)||{icon:'📦'}).icon;
async function api(url, opts={}) {
 const res = await fetch(url, opts);
 const data = await res.json().catch(()=>({error:'Server je vratio neočekivan odgovor.'}));
 if (!res.ok) throw new Error(data.error || 'Došlo je do greške.');
 return data;
}
function toast(msg) {
 $('toast').textContent=msg; $('toast').classList.remove('hidden');
 clearTimeout(window.toastTimer); window.toastTimer=setTimeout(()=>$('toast').classList.add('hidden'),3600);
}
function showModal(id){$(id).classList.remove('hidden');document.body.style.overflow='hidden'}
function hideModal(id){$(id).classList.add('hidden');if(!document.querySelector('.modal-backdrop:not(.hidden)'))document.body.style.overflow=''}
function fillCategories(){
 $('categories').innerHTML=CATEGORIES.map(c=>`<button class="category-tile ${activeCategory===c.name?'selected':''}" data-category="${esc(c.name)}"><span class="category-emoji">${c.icon}</span><span>${esc(c.name)}</span></button>`).join('');
 $('searchCategory').innerHTML='<option value="">Sve kategorije</option>'+CATEGORIES.map(c=>`<option>${esc(c.name)}</option>`).join('');
 $('adCategory').innerHTML='<option value="">Izaberi kategoriju</option>'+CATEGORIES.map(c=>`<option>${esc(c.name)}</option>`).join('');
}
function renderAds(){
 const grid=$('adGrid');
 if(!ads.length){grid.innerHTML=`<div class="empty-state"><div style="font-size:36px;margin-bottom:12px">🛍️</div><b>Još nema oglasa u ovoj pretrazi</b><span>Možeš biti prvi koji će postaviti oglas.</span><p style="margin-top:16px"><button class="btn btn-primary" onclick="openPost()">＋ Postavi prvi oglas</button></p></div>`;return;}
 grid.innerHTML=ads.map(ad=>`<article class="ad-card" data-ad="${ad.id}"><div class="ad-image">${ad.image?`<img src="${esc(ad.image)}" alt="${esc(ad.title)}" loading="lazy">`:`<span class="no-photo">${iconFor(ad.category)}</span>`}<span class="ad-tag">${esc(ad.category)}</span></div><div class="ad-body"><h3>${esc(ad.title)}</h3><div class="ad-price">${money(ad.price)}</div><div class="ad-desc">${esc(ad.description)}</div><div class="ad-meta"><span>📍 ${esc(ad.city)}</span><span>${esc(ad.seller||'Korisnik')}</span></div></div></article>`).join('');
}
async function loadAds(){
 $('adGrid').innerHTML='<div class="loading">Učitavanje oglasa…</div>';
 try{
 const p=new URLSearchParams();
 const q=$('q').value.trim(); if(q)p.set('q',q);
 const category=activeCategory||$('searchCategory').value; if(category)p.set('category',category);
 ads=(await api('/api/ads?'+p.toString())).ads;
 renderAds();
 }catch(e){$('adGrid').innerHTML=`<div class="empty-state"><b>Oglasi trenutno nisu dostupni</b><span>${esc(e.message)}</span><p>Proveri da li je server pokrenut.</p></div>`;}
}
function setAuthMode(mode){
 authMode=mode;
 $('loginTab').classList.toggle('active',mode==='login');$('registerTab').classList.toggle('active',mode==='register');
 $('nameWrap').classList.toggle('hidden',mode!=='register');
 $('authTitle').textContent=mode==='login'?'Dobro došao nazad':'Napravi svoj nalog';
 $('authSubtitle').textContent=mode==='login'?'Prijavi se i upravljaj svojim oglasima.':'Registracija je besplatna i traje minut.';
 $('authSubmit').textContent=mode==='login'?'Prijavi se':'Napravi nalog';
 $('authError').classList.add('hidden');
 $('authForm').elements.password.autocomplete=mode==='login'?'current-password':'new-password';
}
function updateHeader(){
 $('loginOpen').textContent=me?'Moj nalog':'Prijava';
 $('postOpen').textContent=me?'＋ Postavi oglas':'＋ Postavi oglas';
}
function openAuth(){setAuthMode('login');showModal('authModal')}
function openPost(){
 if(!me){openAuth();toast('Prijavi se ili napravi nalog da postaviš oglas.');return}
 $('adForm').reset();$('adError').classList.add('hidden');showModal('postModal');
}
window.openPost=openPost;
async function refreshMe(){try{me=(await api('/api/me')).user}catch{me=null}updateHeader()}
function showDetail(ad){
 $('detailContent').innerHTML=`${ad.image?`<img class="detail-image" src="${esc(ad.image)}" alt="${esc(ad.title)}">`:`<div class="ad-image" style="height:180px;border-radius:14px"><span style="font-size:60px">${iconFor(ad.category)}</span></div>`}<div class="detail-title"><span class="eyebrow">${esc(ad.category)} · ${esc(ad.city)}</span><h2 style="margin-top:8px">${esc(ad.title)}</h2><div class="detail-price">${money(ad.price)}</div><div class="detail-description">${esc(ad.description)}</div><div class="detail-contact"><b>Prodavac:</b> ${esc(ad.seller||'Korisnik')}<br>${ad.phone?`<b>Telefon:</b> <a href="tel:${esc(ad.phone)}">${esc(ad.phone)}</a>`:'Prodavac nije uneo kontakt telefon.'}<br><b>Lokacija:</b> ${esc(ad.city)}</div></div>`;
 showModal('detailModal');
}
$('categories').addEventListener('click',e=>{const b=e.target.closest('[data-category]');if(!b)return;activeCategory=activeCategory===b.dataset.category?'':b.dataset.category;$('searchCategory').value=activeCategory;fillCategories();loadAds();$('oglasi').scrollIntoView({behavior:'smooth'});});
$('searchForm').addEventListener('submit',e=>{e.preventDefault();activeCategory=$('searchCategory').value;loadAds();$('oglasi').scrollIntoView({behavior:'smooth'});});
$('refreshAds').addEventListener('click',loadAds);
['postOpen','heroPost','bannerPost'].forEach(id=>$(id).addEventListener('click',openPost));
$('loginOpen').addEventListener('click',()=>{if(me)showAccount();else openAuth()});
$('loginTab').addEventListener('click',()=>setAuthMode('login'));$('registerTab').addEventListener('click',()=>setAuthMode('register'));
document.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',()=>hideModal(b.dataset.close)));
document.querySelectorAll('.modal-backdrop').forEach(m=>m.addEventListener('click',e=>{if(e.target===m)hideModal(m.id)}));
document.addEventListener('keydown',e=>{if(e.key==='Escape')document.querySelectorAll('.modal-backdrop:not(.hidden)').forEach(m=>hideModal(m.id))});
$('adGrid').addEventListener('click',e=>{const card=e.target.closest('[data-ad]');if(card){const ad=ads.find(a=>a.id===Number(card.dataset.ad));if(ad)showDetail(ad)}});
$('authForm').addEventListener('submit',async e=>{
 e.preventDefault();const f=new FormData(e.currentTarget);const body=Object.fromEntries(f.entries());
 $('authError').classList.add('hidden');$('authSubmit').disabled=true;
 try{const data=await api('/api/'+(authMode==='login'?'login':'register'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});me=data.user;updateHeader();hideModal('authModal');toast(authMode==='login'?'Uspešno si se prijavio.':'Nalog je napravljen.');}
 catch(err){$('authError').textContent=err.message;$('authError').classList.remove('hidden')}
 finally{$('authSubmit').disabled=false}
});
$('adForm').addEventListener('submit',async e=>{
 e.preventDefault();if(!me){hideModal('postModal');openAuth();return}
 const f=new FormData(e.currentTarget);const file=f.get('image');
 if(file&&file.size>5*1024*1024){$('adError').textContent='Fotografija mora biti manja od 5 MB.';$('adError').classList.remove('hidden');return}
 $('adError').classList.add('hidden');const btn=e.currentTarget.querySelector('button[type=submit]');btn.disabled=true;btn.textContent='Šaljem oglas…';
 try{const data=await api('/api/ads',{method:'POST',body:f});hideModal('postModal');toast(data.message);e.currentTarget.reset();await loadAds();}
 catch(err){$('adError').textContent=err.message;$('adError').classList.remove('hidden')}
 finally{btn.disabled=false;btn.textContent='Pošalji oglas na proveru'}
});
async function showAccount(){
 try{
 const data=await api('/api/my-ads');
 const mine=data.ads;
 $('detailContent').innerHTML=`<span class="eyebrow">KORISNIČKI NALOG</span><h2 style="margin-top:10px">Zdravo, ${esc(me.name)}</h2><p class="muted">${esc(me.email)}</p><div style="display:flex;gap:10px;flex-wrap:wrap;margin:18px 0"><button class="btn btn-primary" id="accountPost">＋ Postavi oglas</button><button class="btn btn-outline" id="logoutBtn">Odjavi se</button></div><h3>Moji oglasi (${mine.length})</h3>${mine.length?mine.map(a=>`<div style="display:flex;align-items:center;gap:12px;border-top:1px solid var(--line);padding:12px 0"><div style="font-size:25px">${iconFor(a.category)}</div><div style="flex:1;min-width:0"><b style="font-size:13px">${esc(a.title)}</b><div class="muted">${money(a.price)} · ${esc(a.city)} · ${a.status==='approved'?'Objavljen':a.status==='rejected'?'Odbijen':'Na proveri'}</div></div><button class="btn btn-outline" data-delete="${a.id}">Obriši</button></div>`).join(''):'<p class="muted">Još nemaš oglase. Postavi svoj prvi oglas!</p>'}`;
 showModal('detailModal');
 $('accountPost').addEventListener('click',()=>{hideModal('detailModal');openPost()});
 $('logoutBtn').addEventListener('click',async()=>{await api('/api/logout',{method:'POST'});me=null;updateHeader();hideModal('detailModal');toast('Odjavljen si.');});
 $('detailContent').querySelectorAll('[data-delete]').forEach(b=>b.addEventListener('click',async()=>{if(!confirm('Da li sigurno želiš da obrišeš oglas?'))return;try{await api('/api/ads/'+b.dataset.delete,{method:'DELETE'});toast('Oglas je obrisan.');showAccount();loadAds()}catch(e){toast(e.message)}}));
 }catch(e){toast(e.message)}
}
$('year').textContent=new Date().getFullYear();
fillCategories();
refreshMe();
loadAds();
